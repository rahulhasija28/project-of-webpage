function GetFormData() {

    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let mobile = document.getElementById("mobile").value;
    let discription = document.getElementById("discription").value;


    

      if (email == "") {
        document.getElementById("emailError").innerHTML = "Please enter valid email";
        return false;
      } else if (email != email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
        document.getElementById("emailError").innerHTML = "email is Invaild";
      } else {
        document.getElementById("emailError").innerHTML = "";
      }

      if (mobile == "") {
        //alert('name');
        document.getElementById("mobileError").innerHTML =
          "Please enter your mobile number";
        return false;
      }
    
      else if (mobile != mobile.match(/^\d{10}$/)) {
        document.getElementById("mobileError").innerHTML = "Please enter 10 digit mobile number";
      }
    
      else {
        document.getElementById("mobileError").innerHTML = "";
      }
    

      let personDetails = {
        "Name": name, "Email": email, "Mobile": mobile, "Discription":discription
      };
      alert(JSON.stringify(personDetails));

}

